'use strict';
(function (angular) {
  angular
    .module('couponPluginDesign', [])
    .config([function () {

    }])
})(window.angular);
