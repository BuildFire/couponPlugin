'use strict';
(function (angular) {
  angular
    .module('couponPluginSettings', [
          'couponPluginSettingsServices',
          'couponPluginSettingsEnums'
      ])
    .config([function () {
    }])
})(window.angular);